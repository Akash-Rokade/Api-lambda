def lambda_handler(event, context):
    # Get the value of the 'name' key from the event
    name = event.get('name', 'Anonymous')

    # Create a greeting message
    greeting = f"Hello, {name}! This is a sample Lambda function."

    # Return the greeting message
    return {
        'statusCode': 200,
        'body': greeting
    }
